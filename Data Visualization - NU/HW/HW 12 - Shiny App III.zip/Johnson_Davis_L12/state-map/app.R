# L12 state-map

# load packages
library(shiny)
library(tidyverse)
library(sf)


# Read the county data
county_data <- read_sf("data/county_data.shp")

#capitalize state names
county_data$state <- tools::toTitleCase(county_data$state)

# Define UI for application
ui <- fluidPage(
  titlePanel(h2("County Demographic Map by State", style = "font-weight: normal;")),
  
  sidebarLayout(
    sidebarPanel(
      helpText("Create demographic maps with information from the 2010 US Census."),
      # widget to select a state
      selectInput("state",
                  label = "Choose a state to display",
                  choices = unique(county_data$state),
                  selected = "Illinois"),
      # widget to select a demographic variable
      selectInput("variable",
                  label = "Choose a variable to display",
                  choices = c("Percent White" = "white", 
                              "Percent Black" = "black", 
                              "Percent Hispanic" = "hispanic", 
                              "Percent Asian" = "asian"),
                  selected = "Percent White"),
    ),
    
    mainPanel(plotOutput("map"))
  )
)

# Define server logic
server <- function(input, output) {
  output$map <- renderPlot({
    # subset state data by chosen state
    state_data <- subset(county_data, state == input$state)
    # store variable input
    variable <- input$variable
    
    # assign demographic variables to colors
    color <- if (variable == "white") {
      "darkgreen"
    } else if (variable == "black") {
      "black"
    } else if (variable == "hispanic") {
      "darkorange"
    } else if (variable == "asian") {
      "darkviolet"
    } else {
      # Default color 
      "black"
    }
    
    # determine legend title based on demographic variable chosen
    legend_title <- if (variable == "white") {
      "% White"
    } else if (variable == "black") {
      "% Black"
    } else if (variable == "hispanic") {
      "% Hispanic"
    } else if (variable == "asian") {
      "% Asian"
    } else {
      # Default legend title 
      "Legend Title"
    }
    
    # create state map
    ggplot() +
      geom_sf(data = state_data, aes(fill = .data[[variable]])) +
      scale_fill_gradient(name = legend_title,
                          high = color, 
                          low = "white",
                          breaks = c(0, 25, 50, 75, 100),
                          limits = c(0, 100)) +
      ggtitle(input$state) +
      theme_void() +
      theme(
        plot.title = element_text(size = 18, hjust = 0.5, face = "bold"))
  })
}

# Run the application
shinyApp(ui = ui, server = server)
