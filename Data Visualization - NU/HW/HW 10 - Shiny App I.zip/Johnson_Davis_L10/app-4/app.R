# L10 app-4

#load packages
library(shiny)
library(tidyverse)
library(sf)
library(tigris)

# Define UI ----
ui <- fluidPage(
  # create title
  titlePanel("Florida"),
  # create sidebar content
  sidebarLayout(
    sidebarPanel(
      h3("Fun Facts"),
      p(strong("State Nickname:"),
        "The Sunshine State (sorry, South Dakota)"),
      p(strong("State Motto:"),
        '"In God We Trust"'),
      p(strong("Population:"),
        "21.78 million (est 2021)"),
      p(strong("State Tree:"),
        "Sabal Palm"),
      p(strong("State Animal:"),
        "Florida Panther"),
      p(strong("State Flag:")),
      img(src = "Florida_state_flag.png", height = 125, width = 175),
      br(),
      br(),
      p(strong("State Seal:")),
      img(src = "Seal_of_Florida.png", height = 150, width = 175),
    ),
    # create main panel content
    mainPanel(
      plotOutput("map_plot"),
      HTML("<ul>
        <li>Florida has the longest coastline in the contiguous United States.</li>
        <li>Florida is home to the oldest city in the United States, St. Augustine.</li>
        <li>Visit Florida's <a href='https://en.wikipedia.org/wiki/Florida'>Wikipedia page</a> to learn more.</li>
      </ul>")
    )
  )
)

# Define server logic ----
server <- function(input, output) {
  
  # create Florida map
  invisible(fl_counties <- counties(state = "FL", cb = TRUE))
  
  
  output$map_plot <- renderPlot({
    ggplot(fl_counties) +
      geom_sf(fill = "lightblue") +
      coord_sf() +
      theme_void()
  })
  
}
  


# Run the app ----
shinyApp(ui = ui, server = server)
