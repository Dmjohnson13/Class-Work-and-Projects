# L10 app-3


# load package(s)
library(shiny)
library(tidyverse)

# load cdc data
cdc <- read_delim(file = "cdc copy 2.txt", delim = "|") %>%
  mutate(
    genhlth = factor(
      genhlth,
      levels = c("excellent", "very good", "good", "fair", "poor"),
      labels = c("Excellent", "Very Good", "Good", "Fair", "Poor")
    )
  )

# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("CDC BFRSS: Histogram of Weight Grouped by Gender"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(position = "right",
                sidebarPanel(
                  sliderInput("bins",
                              "Number of bins:",
                              min = 5,
                              max = 50,
                              value = 30,
                              animate = TRUE)
                ),
                
                # Show a plot of the generated distribution
                mainPanel(
                  plotOutput("distPlot")
                )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  output$distPlot <- renderPlot({
    # create bins using weight variable
    bin_breaks <- seq(min(cdc$weight), max(cdc$weight), length.out = input$bins + 1)
    # create histogram
    ggplot(data = cdc, aes(x = weight, fill = gender)) +
      geom_histogram(
        breaks = bin_breaks,
        color = "black"
      ) +
      scale_fill_discrete(
        name = "Gender",
        limits = c("f", "m"),
        labels = c("Female", "Male")) +
      theme_minimal() +
      theme(
        legend.position = c(0.5, 0.75)
      ) +
      labs(
        x = "Weight in Pounds",
        y = "Count",
        fill = "Gender"
      ) +
      theme(
        plot.title = element_text(face = "bold"),
      )
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
