# L10 app-1

# load package(s)
library(shiny)
library(tidyverse)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Hello World!"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("bins",
                        "Number of bins:",
                        min = 5,
                        max = 50,
                        value = 30,
                        animate = TRUE)
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("distPlot")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$distPlot <- renderPlot({
        # generate bins based on input$bins from 
        x    <- faithful$waiting
        bin_breaks <- seq(min(x), max(x), length.out = input$bins + 1)

        # create histogram
      ggplot(data = faithful, aes(x = waiting)) +
        geom_histogram(
          fill = '#007bc2',
          color = "orange",
          breaks = bin_breaks
          ) +
        theme_minimal() +
        labs(
          title = "Histogram of waiting times",
          x = "Waiting time to next eruption (in mins)",
          y = "Frequency"
        ) +
        theme(
          plot.title = element_text(face = "bold", hjust = 0.5),
          )
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
