# L11 Exercise 2


# load package(s)
library(shiny)
library(tidyverse)
library(ggthemes)

# load cdc data
cdc <- read_delim(file = "cdc copy.txt", delim = "|") %>%
  mutate(
    genhlth = factor(
      genhlth,
      levels = c("excellent", "very good", "good", "fair", "poor"),
      labels = c("Excellent", "Very Good", "Good", "Fair", "Poor")
    ),
    gender = factor(
      gender,
      levels = c("f", "m"),
      labels = c("Female", "Male")
    ),
    exerany = factor(
      exerany,
      levels = c(1, 0),
      labels = c("Yes", "No")
    ),
    hlthplan = factor(
      hlthplan,
      levels = c(1, 0),
      labels = c("Yes", "No")
    ),
    smoke100 = factor(
      smoke100,
      levels = c(1, 0),
      labels = c("Yes", "No")
    )
  )


# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("CDC BFRSS Histograms"),
  
  # Sidebar panel
  sidebarLayout(position = "right",
                sidebarPanel(
                  # selector to pick x-variable
                  selectInput("variable",
                              label = "Select Variable:",
                              choices = c("Actual Weight" = "weight",
                                          "Desired Weight" = "wtdesire",
                                          "Height" = "height"),
                              selected = "weight"),
                  # slider to pick number of bins
                  sliderInput("bins",
                              "Number of bins:",
                              min = 5,
                              max = 50,
                              value = 30,
                              animate = TRUE),
                  # buttons to choose fill variable
                  radioButtons("fill",
                               label = "Select Fill/Legend Variable:",
                               choices = list(
                                 "General Health" = "genhlth",
                                 "Health Coverage" = "hlthplan",
                                 "Exercised in Past Month" = "exerany",
                                 "Smoked 100 Cigarttes" = "smoke100",
                                 "Gender" = "gender"),
                               selected = "genhlth")
                ),
                
                # Show a plot of the generated distribution
                mainPanel(
                  plotOutput("cdcPlot")
                )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  output$cdcPlot <- renderPlot({
    # create bin breaks based on user selection of x-variable
    bin_breaks <- seq(min(cdc[[input$variable]]), max(cdc[[input$variable]]), length.out = input$bins + 1)
  
    # build x-axis title
    x_title <- case_when(
      input$variable == "weight" ~ "Weight in Pounds",
      input$variable == "wtdesire" ~ "Weight in Pounds",
      input$variable == "height" ~ "Height in Inches"
    )

    # draw histogram with selected x-variable and fill variable
    ggplot(data = cdc, aes(x = !!sym(input$variable), fill = !!sym(input$fill))) +
      geom_histogram(
        breaks = bin_breaks,
        color = "black"
      ) +
      theme_fivethirtyeight() +
      theme(
        legend.position = "top",
        legend.background = element_blank(),
        legend.title = element_text(hjust = 0.5),
        axis.title = element_text()
      ) +
      labs(
        x = x_title,
        y = "Count"
      ) +
      guides(fill = guide_legend(title.position = "top")) +
      scale_fill_discrete(name = ifelse(input$fill == "genhlth", "General Health",
                                        ifelse(input$fill == "hlthplan", "Health Coverage",
                                               ifelse(input$fill == "exerany", "Exercised in Past Month",
                                                      ifelse(input$fill == "smoke100", "Smoked 100 Cigarettes",
                                                             "Gender"
                                                      )
                                               )
                                        )
      )
      )
  })
}
# Run the application 
shinyApp(ui = ui, server = server)