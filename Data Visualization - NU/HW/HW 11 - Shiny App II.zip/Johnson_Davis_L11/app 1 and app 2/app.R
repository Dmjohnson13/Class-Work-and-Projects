
# L11 Exercise 1 and 2

# load package(s)
library(shiny)

# Define UI ----
ui <- fluidPage(
  titlePanel("censusVis"),
  #sidebar panel
  sidebarLayout(
    sidebarPanel(
      # create help text to describe inputs
      helpText("Create demographic maps with information from the 2010 US Census."),
      # selector that allows user to choose a variable
      selectInput("var", 
                  label = "Choose a variable to display",
                  choices = list("Percent White", "Percent Black", "Percent Hispanic", "Percent Asian"),
                  selected = "Percent White"),
      # slider that allows users to customize a range
      sliderInput("range", 
                  label = "Range of interest:",
                  min = 0, max = 100, value = c(0, 100))
    ),
    # display selected variable and range in main panel
    mainPanel(
      textOutput("selected_var"),
      textOutput("selected_range")
    )
  )
)

# Define server logic ----
server <- function(input, output) {
  # generate text that shows which variable user selected
  output$selected_var <- renderText({
    paste("You have selected", input$var)
  })
  # generate text that shows which range user selected
  output$selected_range <- renderText({
    paste("You have chosen a range that goes from", input$range[1], "to", input$range[2])
})
}

# Run the app ----
shinyApp(ui = ui, server = server)
