# -------------------------------------------------------------------------------
# Start of the setup code.
# DO NOT change any of the setup code!

# Note: the following setup code will generate an empty database file (music.db)
# and import the music.csv into the database as a table (named as "data").

import csv, sqlite3
from sqlite3 import Error

with open('music.csv','r',encoding='utf-8') as f:
    to_db=[tuple(line) for line in csv.reader(f)]

head_tuple=tuple(to_db[0])


con = sqlite3.connect("music.db") 
cur = con.cursor()

cur.execute("DROP TABLE IF EXISTS source_dataset")
cur.execute("CREATE TABLE source_dataset "+str(head_tuple)+" ;") 
cur.executemany("INSERT INTO source_dataset "+str(head_tuple)+" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);", to_db[1:])

con.commit()
con.close()

# end of setup code
# ---------------------------------------------------------------------------------




con = sqlite3.connect("music.db") 
cur = con.cursor()

# TODO: put all your code inside the variable "script".
script='''

DROP TABLE IF EXISTS media_types;
DROP TABLE IF EXISTS genre;
DROP TABLE IF EXISTS artist;
DROP TABLE IF EXISTS album;
DROP TABLE IF EXISTS tracks;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Invoice;
DROP TABLE IF EXISTS Invoice_items;


--Create media_types table

CREATE TABLE media_types (
mediaTypeID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL  ,
name TEXT
);

--Populate media_types table

INSERT INTO media_types (name)
SELECT DISTINCT MediaType from source_dataset;

--Create genre table

CREATE TABLE genre (
genreID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL  ,
name TEXT
);

--Populate genre table

INSERT INTO genre (name)
SELECT DISTINCT Genre from source_dataset;

--Create artist table

CREATE TABLE artist (
artistId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL  ,
artistName TEXT
);

--Populate artist table

INSERT INTO artist (artistName)
SELECT DISTINCT ArtistName from source_dataset;

--Create album table

CREATE TABLE album (
albumId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
albumTitle TEXT NOT NULL ,
artistId INTEGER NOT NULL
    REFERENCES artist(artistId)  
);

--Populate album table

INSERT INTO album (albumTitle, artistId)
SELECT DISTINCT AlbumTitle, artistId FROM source_dataset 
JOIN artist ON artist.artistName = source_dataset.ArtistName;

--Create tracks table

CREATE TABLE tracks (
trackId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
trackName TEXT NOT NULL ,
composer TEXT ,
trackSizeByte INTEGER ,
trackLength INTEGER ,
trackprice REAL ,
genreId INTEGER NOT NULL REFERENCES genre(genreId) ,
mediaTypeId INTEGER NOT NULL REFERENCES media_types(mediaTypeId) ,
albumId INTEGER NOT NULL REFERENCES album(albumId)
); 

--Populate tracks table

INSERT INTO tracks (trackName, composer, trackSizeByte, trackLength, trackprice, genreId, mediaTypeId, albumId)
SELECT DISTINCT TrackName, Composer, TrackSizeBytes, TrackLength, TrackPrice, genreId, mediaTypeId, albumID
FROM source_dataset
JOIN album ON album.albumTitle = source_dataset.AlbumTitle
JOIN genre ON genre.name = source_dataset.Genre
JOIN media_types ON media_types.name = source_dataset.MediaType;

--Create Customer table

CREATE TABLE Customer (
customerId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
firstName TEXT NOT NULL , 
lastName TEXT NOT NULL UNIQUE , 
address TEXT , 
city TEXT ,
state TEXT ,
country TEXT ,
postalCode TEXT, 
phoneNumber TEXT , 
faxNumber TEXT ,
email TEXT NOT NULL
);

--Populate Customer table

INSERT INTO Customer (firstName, lastName, address, city, state, country, postalCode, phoneNumber, faxNumber, email)
SELECT DISTINCT CustomerFirstName, CustomerLastName, CustomerAddress, CustomerCity, CustomerState, 
CustomerCountry, CustomerPostalCode, CustomerPhone, CustomerFax, CustomerEmail FROM source_dataset 
WHERE CustomerLastName != '';

--Create Invoice table

CREATE TABLE Invoice (
InvoiceId INTEGER PRIMARY KEY NOT NULL ,
Date DATETIME NOT NULL ,
billingAddress TEXT ,
billingCity TEXT ,
billingState TEXT ,
billingCountry TEXT,
billingPostalCode TEXT,
customerId INTEGER NOT NULL REFERENCES Customer(customerId)
); 

--Populate Invoice table

INSERT INTO Invoice
SELECT DISTINCT InvoiceId, InvoiceDate, InvoiceBillingAddress, InvoiceBillingCity, 
InvoiceBillingState, InvoiceBillingCountry, InvoiceBillingPostalCode, customerId 
FROM source_dataset JOIN Customer ON source_dataset.CustomerLastName = Customer.lastName;

--Create Invoice_items table

CREATE TABLE Invoice_items (
InvoiceItemId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
InvoiceId INTEGER NOT NULL REFERENCES Invoice(InvoiceId) ,
trackId INTEGER NOT NULL REFERENCES tracks(trackId) ,
quantity INTEGER ,
unitPrice REAL 
); 

--Populate Invoice_items table

INSERT INTO Invoice_items (InvoiceId, trackId, quantity, unitPrice)
SELECT DISTINCT InvoiceId, trackId, InvoiceItemQuantity, InvoiceItemUnitPrice FROM source_dataset
NATURAL JOIN Invoice
JOIN tracks on source_dataset.TrackName = tracks.trackName AND source_dataset.TrackLength = tracks.trackLength; 




'''


cur.executescript(script)
con.commit()
con.close()
