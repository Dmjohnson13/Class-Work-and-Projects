import json
#DO NOT CHANGE any function names!



#-----------------------Q0-----------------------
# Please copy the code snippet in the following area.

import requests

url = "https://covid-19-statistics.p.rapidapi.com/reports"

querystring = {"city_name":"Autauga","region_province":"Alabama","iso":"USA","region_name":"US","q":"US Alabama","date":"2020-04-16"}

headers = {
    'x-rapidapi-host': "covid-19-statistics.p.rapidapi.com",
    'x-rapidapi-key': "b05343280fmshcf191d96b568b05p1b5586jsn964912fa743f"
    }

response = requests.request("GET", url, headers=headers, params=querystring)

print(response.text)


#-----------------------Q1-----------------------
def death_count_il():
    querystring = {'region_province': 'Illinois', 'date': '2020-11-16'}
    response = requests.request('GET', url, headers=headers, params=querystring)
    data = json.loads(response.text)
    return data['data'][0]['deaths']



###-----------------------Q2-----------------------
def get_death_count(state, date):
    querystring = {'region_province': state, 'date': date}
    response = requests.request('GET', url, headers=headers, params=querystring)
    data = json.loads(response.text)['data']
    if (data == []):
        return 0
    else:
        return data[0]['deaths']
    



    
#-----------------------Q3-----------------------
def get_confirmed_count(state, date):
    querystring = {'region_province': state, 'date': date}
    response = requests.request('GET', url, headers=headers, params=querystring)
    data = json.loads(response.text)['data']
    if (data == []):
        return 0
    else:
        return data[0]['confirmed']

    

def get_from_dates(state, dates):
    date_list = []
    for date in dates:
       confirmed_cases = get_confirmed_count(state, date)
       date_list.append(confirmed_cases)
    return date_list
        
 


        


#-----------------------Q4-----------------------
def get_us_confirmed_count(date):
    querystring = {'iso': 'USA', 'date': date}
    response = requests.request('GET', url, headers=headers, params=querystring)
    data = json.loads(response.text)['data']
    death_count = data
    death_count_length = len(death_count)
    total_count = 0
    if (data == []):
        return 0
    else:
        for i in range(death_count_length):
            total_count += death_count[i]["confirmed"]
        return total_count


    


#-----------------------Q5-----------------------
def death_difference(state, start_date, end_date):
    d1 = get_death_count(state, start_date)
    d2 = get_death_count(state, end_date)
    return abs(d2-d1)
def count_difference(state, start_date, end_date):
    c1 = get_confirmed_count(state, start_date)
    c2 = get_confirmed_count(state, end_date)
    return abs(c2-c1)

def surging_factor(state, start_date, end_date):
    new_death = death_difference(state, start_date, end_date)
    new_confirmed = count_difference(state, start_date, end_date)
    surge_factor = (new_death * new_confirmed)
    return surge_factor


