# --------------------------------------------------
# Start of the setup code.
# DO NOT change any of the setup code!
import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print("create_connection error:")
        print(e)
    return conn

def execute_query(conn, query):
    result = ""
    try:
        cur = conn.cursor()
        cur.execute(query)
        rows = cur.fetchall()
        for row in rows:
            result += str(row)+"\n"
    except Error as e:
        print("execute_query error:")
        print(e)
    return result

db_recipe = 'Recipes.sqlite'
db_music = 'EntertainmentAgency.sqlite'
db_school = 'SchoolScheduling.sqlite'
conn1 = create_connection(db_recipe)
conn2 = create_connection(db_music)
conn3 = create_connection(db_school)

# end of setup code
# --------------------------------------------------




# --------------------------------------------------
# Your work starts here.
# TODO: put your sql query in the following triple quotes.
# DO NOT change variable names.


query1 = ''' SELECT Recipes.RecipeTitle
    FROM Recipes 
    NATURAL JOIN Recipe_Ingredients
    GROUP BY RecipeID HAVING COUNT(*) > 8
    ORDER BY COUNT(*) DESC;

'''
query2 = ''' SELECT Ingredients.IngredientName FROM Ingredients
    LEFT JOIN Recipe_Ingredients
    ON Ingredients.IngredientID =
    Recipe_Ingredients.IngredientID
    WHERE Recipe_Ingredients.RecipeID IS NULL
    GROUP BY IngredientName;

'''
query3 = ''' SELECT CustFirstName || ' '|| CustLastName AS Name FROM Customers
LEFT JOIN Musical_Preferences ON
Musical_Preferences.CustomerID = Customers.CustomerID
WHERE Musical_Preferences.StyleID =
(SELECT StyleID FROM Musical_Styles WHERE StyleName = 'Modern Rock');

'''
query4 = ''' SELECT Entertainers.EntStageName, Agents.AgtFirstName, Agents.AgtLastName
FROM Agents
LEFT JOIN Engagements 
    ON Agents.AgentId = Engagements.AgentID
LEFT JOIN Entertainers
    ON Engagements.EntertainerID = Entertainers.EntertainerID
WHERE Engagements.StartDate <= '2012-10-20' AND Engagements.EndDate >= '2012-10-20';

'''
query5 = ''' SELECT EntStageName FROM Entertainers
LEFT JOIN Entertainer_Styles ON Entertainer_Styles.EntertainerID = Entertainers.EntertainerID
WHERE Entertainer_Styles.StyleID IN 
(SELECT StyleID FROM Musical_Styles WHERE StyleName = "60's Music" OR StyleName = "70's Music");

'''

query6 = ''' SELECT Entertainers.EntCity AS City, 1.0*SUM(Gender = 'F')/COUNT(*) AS Female_Proportion FROM Entertainers
LEFT JOIN Entertainer_Members ON Entertainer_Members.EntertainerID = Entertainers.EntertainerID
LEFT JOIN Members ON Members.MemberID = Entertainer_Members.MemberID
GROUP BY Entertainers.EntCity;

'''
query7 = ''' SELECT Students.StudFirstName, Students.StudLastName, Majors.Major, COUNT(Student_Schedules.StudentID) AS Number_of_Classes 
FROM Students
INNER JOIN Majors ON Majors.MajorID = Students.StudMajor 
LEFT JOIN Student_Schedules ON Student_Schedules.StudentID = Students.StudentID WHERE Student_Schedules.ClassStatus != 
(SELECT ClassStatus FROM Student_Class_Status WHERE ClassStatusDescription = 'Withdrew')
GROUP BY StudLastName;

'''
query8 = ''' SELECT Subjects.SubjectName, AVG(Student_Schedules.Grade) AS Grade_Average FROM Subjects
LEFT JOIN Classes ON Classes.SubjectID = Subjects.SubjectID
LEFT JOIN Student_Schedules ON Student_Schedules.ClassID = Classes.ClassID WHERE Student_Schedules.ClassStatus = 
(SELECT ClassStatus FROM Student_Class_Status WHERE ClassStatusDescription = 'Completed')
GROUP BY Subjects.SubjectID
ORDER BY Grade_Average DESC;

'''
query9 = ''' SELECT DISTINCT SubjectCode, SubjectName FROM Subjects
NATURAL JOIN Classes  
NATURAL JOIN Class_Rooms 
NATURAL JOIN Student_Schedules
NATURAL JOIN Buildings
NATURAL JOIN Student_Class_Status WHERE BuildingName = 'College Center' AND SemesterNumber = '1' 
and MondaySchedule + TuesdaySchedule + WednesdaySchedule + ThursdaySchedule + FridaySchedule + SaturdaySchedule > 4 AND 
ClassStatusDescription != 'Withdrew'
GROUP BY SubjectCode;

'''
query10 = ''' SELECT Students.StudFirstName, Students.StudLastName FROM Students 
LEFT JOIN
   (SELECT Student_Schedules.StudentID
    FROM Student_Class_Status
    INNER JOIN Student_Schedules
    on Student_Class_Status.ClassStatus = Student_Schedules.ClassStatus
    WHERE Student_Class_Status.ClassStatusDescription = 'Withdrew')
  AS Student_Withdrew
  ON Students.StudentID = Student_Withdrew.StudentID
WHERE Student_Withdrew.StudentID IS NULL;

'''
# End of your work.
# --------------------------------------------------





# --------------------------------------------------
# printing out results.
# DO NOT change any of the following code!

print(db_recipe,':')
print('Q1:\n',execute_query(conn1, query1))
print('Q2:\n',execute_query(conn1, query2))

print(db_music,':')
print('Q3:\n',execute_query(conn2, query3))
print('Q4:\n',execute_query(conn2, query4))
print('Q5:\n',execute_query(conn2, query5))
print('Q6:\n',execute_query(conn2, query6))

print(db_school,":")

print('Q7:\n',execute_query(conn3, query7))
print('Q8:\n',execute_query(conn3, query8))
print('Q9:\n',execute_query(conn3, query9))
print('Q10:\n',execute_query(conn3, query10))

conn1.close()
conn2.close()
conn3.close()
