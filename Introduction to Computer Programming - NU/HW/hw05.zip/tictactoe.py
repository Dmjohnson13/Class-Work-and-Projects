import time
import random
def print_board(game_data):
    print()
    print('', game_data[6], '|', game_data[7], '|', game_data[8], '       7 | 8 | 9 ')
    print('-'* 11, '    ', '-'* 11)
    print('', game_data[3], '|', game_data[4], '|', game_data[5], '       4 | 5 | 6 ')
    print('-'* 11, '    ', '-'* 11)
    print('', game_data[0], '|', game_data[1], '|', game_data[2], '       1 | 2 | 3 ')
    print()
def game_winner_player():
    if player_symbol == game_data[6] and player_symbol == game_data[7] and player_symbol == game_data[8]:
        print('You win!')
        return True
    elif player_symbol == game_data[3] and player_symbol == game_data[4] and player_symbol == game_data[5]:
        print('You win!')
        return True
    elif player_symbol == game_data[0] and player_symbol == game_data[1] and player_symbol == game_data[2]:
        print('You win!')
        return True
    elif player_symbol == game_data[6] and player_symbol == game_data[3] and player_symbol == game_data[0]:
        print('You win!')
        return True
    elif player_symbol == game_data[7] and player_symbol == game_data[4] and player_symbol == game_data[1]:
        print('You win!')
        return True
    elif player_symbol == game_data[8] and player_symbol == game_data[5] and player_symbol == game_data[2]:
        print('You win!')
        return True
    elif player_symbol == game_data[6] and player_symbol == game_data[4] and player_symbol == game_data[2]:
        print('You win!')
        return True
    elif player_symbol == game_data[0] and player_symbol == game_data[4] and player_symbol == game_data[8]:
        print('You win!')
        return True
    else:
        return False
def game_winner_computer():
    if computer_symbol == game_data[6] and computer_symbol == game_data[7] and computer_symbol == game_data[8]:
        print('The computer wins!')
        return True
    elif computer_symbol == game_data[0] and computer_symbol == game_data[1] and computer_symbol == game_data[2]:
        print('The computer wins!')
        return True
    elif computer_symbol == game_data[3] and computer_symbol == game_data[4] and computer_symbol == game_data[5]:
        print('The computer wins!')
        return True
    elif computer_symbol == game_data[6] and computer_symbol == game_data[3] and computer_symbol == game_data[0]:
        print('The computer wins!')
        return True
    elif computer_symbol == game_data[7] and computer_symbol == game_data[4] and computer_symbol == game_data[1]:
        print('The computer wins!')
        return True
    elif computer_symbol == game_data[8] and computer_symbol == game_data[5] and computer_symbol == game_data[2]:
        print('The computer wins!')
        return True
    elif computer_symbol == game_data[6] and computer_symbol == game_data[4] and computer_symbol == game_data[2]:
        print('The computer wins!')
        return True
    elif computer_symbol == game_data[0] and computer_symbol == game_data[4] and computer_symbol == game_data[8]:
        print('The computer wins!')
        return True
    else:
        return False

def game_tied():
    if game_data[0] != ' ' and game_data[1] != ' ' and game_data[2] != ' ' and game_data[3] != ' ' and game_data[4] != ' ' and game_data[5] != ' ' and game_data[6] != ' ' and game_data[7] != ' ' and game_data[8] != ' ' and game_winner_player() == False and game_winner_computer() == False:
        print('The game ended in a tie!')
        return True
    else:
        return False
    
computer_move = None
computer_choice = None
def smart_computer_offense():
    global computer_choice
    if game_data[6] == computer_symbol and game_data[3] == computer_symbol and game_data[0] == ' ':
        computer_choice = 0
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == computer_symbol and game_data[1] == computer_symbol and game_data[0] == ' ':
        computer_choice = 0
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[8] == computer_symbol and game_data[4] == computer_symbol and game_data[0] == ' ':
        computer_choice = 0
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[7] == computer_symbol and game_data[4] == computer_symbol and game_data[1] == ' ':
        computer_choice = 1
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == computer_symbol and game_data[2] == computer_symbol and game_data[1] == ' ':
        computer_choice = 1
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == computer_symbol and game_data[2] == computer_symbol and game_data[2] == ' ':
        computer_choice = 2
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[8] == computer_symbol and game_data[5] == computer_symbol and game_data[2] == ' ':
        computer_choice = 2
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[6] == computer_symbol and game_data[4] == computer_symbol and game_data[2] == ' ':
        computer_choice = 2
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[6] == computer_symbol and game_data[0] == computer_symbol and game_data[3] == ' ':
        computer_choice = 3
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[5] == computer_symbol and game_data[4] == computer_symbol and game_data[3] == ' ':
        computer_choice = 3
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[3] == computer_symbol and game_data[5] == computer_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[7] == computer_symbol and game_data[1] == computer_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == computer_symbol and game_data[8] == computer_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == computer_symbol and game_data[6] == computer_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[3] == computer_symbol and game_data[4] == computer_symbol and game_data[5] == ' ':
        computer_choice = 5
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == computer_symbol and game_data[8] == computer_symbol and game_data[5] == ' ':
        computer_choice = 5
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == computer_symbol and game_data[3] == computer_symbol and game_data[6] == ' ':
        computer_choice = 6
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[8] == computer_symbol and game_data[7] == computer_symbol and game_data[6] == ' ':
        computer_choice = 6
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == computer_symbol and game_data[4] == computer_symbol and game_data[6] == ' ':
        computer_choice = 6
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[1] == computer_symbol and game_data[4] == computer_symbol and game_data[7] == ' ':
        computer_choice = 7
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[6] == computer_symbol and game_data[8] == computer_symbol and game_data[7] == ' ':
        computer_choice = 7
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[6] == computer_symbol and game_data[7] == computer_symbol and game_data[8] == ' ':
        computer_choice = 8
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == computer_symbol and game_data[5] == computer_symbol and game_data[8] == ' ':
        computer_choice = 8
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == computer_symbol and game_data[4] == computer_symbol and game_data[8] == ' ':
        computer_choice = 8
        game_data[computer_choice] = computer_symbol
        return True
    else:
        return False

def smart_computer_defense():
    global computer_choice
    if game_data[6] == player_symbol and game_data[3] == player_symbol and game_data[0] == ' ':
        computer_choice = 0
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == player_symbol and game_data[1] == player_symbol and game_data[0] == ' ':
        computer_choice = 0
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[8] == player_symbol and game_data[4] == player_symbol and game_data[0] == ' ':
        computer_choice = 0
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[7] == player_symbol and game_data[4] == player_symbol and game_data[1] == ' ':
        computer_choice = 1
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == player_symbol and game_data[2] == player_symbol and game_data[1] == ' ':
        computer_choice = 1
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == player_symbol and game_data[2] == player_symbol and game_data[2] == ' ':
        computer_choice = 2
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[8] == player_symbol and game_data[5] == player_symbol and game_data[2] == ' ':
        computer_choice = 2
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[6] == player_symbol and game_data[4] == player_symbol and game_data[2] == ' ':
        computer_choice = 2
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[6] == player_symbol and game_data[0] == player_symbol and game_data[3] == ' ':
        computer_choice = 3
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[5] == player_symbol and game_data[4] == player_symbol and game_data[3] == ' ':
        computer_choice = 3
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[3] == player_symbol and game_data[5] == player_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[7] == player_symbol and game_data[1] == player_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == player_symbol and game_data[8] == player_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == player_symbol and game_data[6] == player_symbol and game_data[4] == ' ':
        computer_choice = 4
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[3] == player_symbol and game_data[4] == player_symbol and game_data[5] == ' ':
        computer_choice = 5
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == player_symbol and game_data[8] == player_symbol and game_data[5] == ' ':
        computer_choice = 5
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == player_symbol and game_data[3] == player_symbol and game_data[6] == ' ':
        computer_choice = 6
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[8] == player_symbol and game_data[7] == player_symbol and game_data[6] == ' ':
        computer_choice = 6
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == player_symbol and game_data[4] == player_symbol and game_data[6] == ' ':
        computer_choice = 6
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[1] == player_symbol and game_data[4] == player_symbol and game_data[7] == ' ':
        computer_choice = 7
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[6] == player_symbol and game_data[8] == player_symbol and game_data[7] == ' ':
        computer_choice = 7
        game_data[computer_choice] = computer_symbol
    elif game_data[6] == player_symbol and game_data[7] == player_symbol and game_data[8] == ' ':
        computer_choice = 8
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[2] == player_symbol and game_data[5] == player_symbol and game_data[8] == ' ':
        computer_choice = 8
        game_data[computer_choice] = computer_symbol
        return True
    elif game_data[0] == player_symbol and game_data[4] == player_symbol and game_data[8] == ' ':
        computer_choice = 8
        game_data[computer_choice] = computer_symbol
        return True
    else:
        return False
       

game_data = [' '] * 9   # initialize game data to an empty array
whose_turn = None
computer_symbol = None
player_symbol = None

#Tic-Tac-Toe Game loop below
# keep looping until there's a winner:

while True:
    while whose_turn == None:
        player_symbol = input('Do you want to be x or o? ')
        if player_symbol.lower() != 'x' and player_symbol.lower() != 'o':
            print('Try again. Your symbol has to be either x or o.')
            continue
        elif player_symbol.lower() == 'x':
            computer_symbol = 'o'
        elif player_symbol.lower() == 'o':
            computer_symbol = 'x'
        yes_or_no = input('Do you want to go first? (Y/N) ')
        if yes_or_no.upper() != 'Y' and yes_or_no.upper() != 'N':
            print('Try again. Type either Y or N.')
            continue
        elif yes_or_no.upper() == 'Y':
            whose_turn = 'player'
        else:
            whose_turn = 'computer'
        print_board(game_data)
    if whose_turn == 'player':
        selection = input('Where would you like to go (1-9 to play, Q to quit)? ')
        if selection.upper() == 'Q':
            print('Terminating the game. Thanks for playing!')
            break
        try:
            selection = int(selection) - 1
        except:
            print('Sorry, must be a number. Try again.')
            continue
        if selection < 0 or selection >= 9:
            print('Number must be in range! Enter a number between 1 and 9.')
            continue
        if game_data[selection] != ' ':
            print('Error! Spot already taken. Try again!')
            continue
        # --------------------------------------------------------------
        # # TODO: Complete Steps 1-3 for Tutorial 8
        # 1. if they typed 'q' or 'Q', break out of the loop
        # 2. check if the user entered a number between 1 and 9 
        #    Note: the code below will fail if the user enters a string.
        # 3. make sure the number they picked isn't already taken


        # --------------------------------------------------------------
        game_data[selection] = player_symbol
        print('You have selected:', selection + 1)
        print_board(game_data)
        whose_turn = 'computer'
            
#      switch to the computer's turn
    
    if game_winner_player() == True:
        print('Thanks for playing!')
        break
    if game_tied() == True:
        print('Thanks for playing!')
        break

    if whose_turn == 'computer':
        # TODO (for HW5): handle computer's turn:
        # your code here...
        if smart_computer_offense() == True:
            print('Computer thinking...')
            time.sleep(2)
            print('The computer has selected:', computer_choice + 1)
            whose_turn = 'player'
            print_board(game_data)
        elif smart_computer_defense() == True:
            print('Computer thinking...')
            time.sleep(2)
            print('The computer has selected:', computer_choice + 1)
            whose_turn = 'player'
            print_board(game_data)
        else:
            computer_selection = random.randint(1, 9)
            computer_move = int(computer_selection - 1)
            if game_data[computer_move] != ' ':
                whose_turn = 'computer'
            else:
                print('Computer is thinking...')
                time.sleep(2)
                print('The computer has selected:', computer_selection)
                game_data[computer_move] = computer_symbol
                whose_turn = 'player'
                print_board(game_data)
    
    if game_winner_computer() == True:
        print('Thanks for playing!')
        break
    if game_tied() == True:
        print('Thanks for playing!')
        break
    
        
##        elif game_data[computer_move] != ' ':
##            continue
            
        # after the computer plays, switch to the player's turn
        # 'smart' computer: 
        


    # TODO (for HW5): each time either the computer plays, 
    # check if someone won or if there's a tie.
