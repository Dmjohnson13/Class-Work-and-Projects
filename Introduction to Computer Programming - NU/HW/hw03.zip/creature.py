import helpers
from tkinter import Canvas, Tk
gui = Tk()
gui.title('Shapes')
canvas = Canvas(gui, width=700, height=700, background='white')
canvas.pack()
helpers.make_grid(canvas, 800, 800)
##def make_creature(canvas):
##    ## TODO: delete all of this code and create *your creature!
##    ## This is just a hard-coded example
##    
##    # face: 
##    helpers.make_circle(canvas, (250, 150), 100, fill='teal')
##    
##    # left eye: 
##    helpers.make_oval(canvas, (225, 130), 10, 18, fill='black')
##    
##    # right eye:
##    helpers.make_oval(canvas, (275, 130), 10, 18, fill='black')


def make_creature(canvas:Canvas, center:tuple, size:int=80, primary_color:str='red', secondary_color:str='yellow'):
      canvas.create_oval(
        [
            (center[0] - size/2, center[1] - size/2), 
            (center[0] + size/2, center[1] + size/2)
        ],
        fill = primary_color)
      canvas.create_oval(
        [
            (center[0] - size/4, center[1] - size/4), 
            (center[0] - size/1.5, center[1] - size/1.5)
        ],
        fill = secondary_color)
      canvas.create_oval(
        [
            (center[0] + size/4, center[1] - size/4), 
            (center[0] + size/1.5, center[1] - size/1.5)
        ],
        fill = secondary_color)
      canvas.create_oval(
        [
            (center[0] - size/4, center[1] + size/4), 
            (center[0] - size/1.5, center[1] + size/1.5)
        ],
        fill = secondary_color)
      canvas.create_oval(
        [
            (center[0] + size/4, center[1] + size/4), 
            (center[0] + size/1.5, center[1] + size/1.5)
        ],
        fill = secondary_color)
      canvas.create_polygon(
          [
              (center[0] - size/10, center[1] - size/9),
              (center[0], center[1] - size/3),
              (center[0] + size/10, center[1] - size/9)
        ],
        fill = 'black')
      canvas.create_oval(
          [
            (center[0] - size/5, center[1] - size/3), 
            (center[0] - size/7, center[1] - size/5)
        ],
        fill = 'black')
      canvas.create_oval(
          [
            (center[0] + size/5, center[1] - size/3), 
            (center[0] + size/7, center[1] - size/5)
        ],
        fill = 'black')
      canvas.create_oval(
          [
            (center[0] - size/11, center[1] - size/15), 
            (center[0] + size/11, center[1] + size/17)
        ],
        fill = 'black')


make_creature(canvas, (92, 115), size=85, primary_color='#5e6976', secondary_color='#1b324d')
make_creature(canvas, (487, 110), size=101, primary_color='#bfdc65', secondary_color='#abb880')
make_creature(canvas, (454, 423), size=141, primary_color='#aebb83', secondary_color='#227876')
make_creature(canvas, (333, 227), size=99, primary_color='#94ba77', secondary_color='#3f5364')
make_creature(canvas, (117, 314), size=91, primary_color='#648d8e', secondary_color='#afc272')
make_creature(canvas, (199, 469), size=122, primary_color='#3f5364', secondary_color='#bfdc65')
