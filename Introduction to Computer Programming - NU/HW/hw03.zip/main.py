from tkinter import Canvas, Tk
from helpers import make_grid
from creature import make_creature

# initialize window
gui = Tk()
gui.title('Creature')
canvas = Canvas(gui, width=550, height=550, background='white')
canvas.pack()
########################## YOUR CODE BELOW THIS LINE ##############################


# Call your creature function with different arguments here:

make_creature(canvas, (92, 115), size=85, primary_color='#5e6976', secondary_color='#1b324d')
make_creature(canvas, (487, 110), size=101, primary_color='#bfdc65', secondary_color='#abb880')
make_creature(canvas, (454, 423), size=141, primary_color='#aebb83', secondary_color='#227876')
make_creature(canvas, (333, 227), size=99, primary_color='#94ba77', secondary_color='#3f5364')
make_creature(canvas, (117, 314), size=91, primary_color='#648d8e', secondary_color='#afc272')
make_creature(canvas, (199, 469), size=122, primary_color='#3f5364', secondary_color='#bfdc65')




########################## YOUR CODE ABOVE THIS LINE ############################## 
# makes sure the canvas keeps running:
canvas.mainloop()

