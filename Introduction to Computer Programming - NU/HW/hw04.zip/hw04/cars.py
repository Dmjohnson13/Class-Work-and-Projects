from tkinter import Canvas, Tk
import time
import helpers

gui = Tk()
gui.title('Animation')
canvas = Canvas(gui, width=500, height=500, background='white')
canvas.pack()
########################## YOUR CODE BELOW THIS LINE ##############################

# draw car (and give it a unique tag 'car1')
helpers.make_car(canvas, top_left=(0, 50), tag='car1')
helpers.make_car(canvas, top_left =(300, 300), color = 'pink', tag='car2')


### move shapes that have the tag 'car1' 50 pixels to the right:
##time.sleep(1)
##helpers.update_position(canvas, 'car1', x=50, y=0)
##gui.update()
##
### move shapes that have the tag 'car1' 50 pixels to the right (exact same code):
##time.sleep(1)
##helpers.update_position(canvas, 'car1', x=50, y=0)
##gui.update()
##
### move shapes that have the tag 'car1' 50 pixels to the right (exact same code):
##time.sleep(1)
##helpers.update_position(canvas, 'car1', x=50, y=0)
##gui.update()


while True:
    helpers.update_position(canvas, 'car1', x=5, y=0)
    helpers.update_position(canvas, 'car2', x=-5, y=0)
    gui.update()
    time.sleep(1/30)
    car_location = helpers._get_coordinates(canvas, 'car1')
    car_x = car_location[0]
    car2_location = helpers._get_coordinates(canvas, 'car2')
    car2_x = car2_location[0]
    if car_x > 550:
        helpers.update_position(canvas, 'car1', x=-725, y=0)
    if car2_x < -150:
        helpers.update_position(canvas, 'car2', x=725, y=0)
    
   
        
    

  
   





########################## YOUR CODE ABOVE THIS LINE ############################## 
# makes sure the canvas keeps running:
canvas.mainloop()
