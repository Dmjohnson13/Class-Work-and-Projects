from tkinter import Canvas, Tk
import helpers
import utilities
import helpers
import time
import random
import math

gui = Tk()
gui.title('My Terrarium')

# initialize canvas:
window_width = gui.winfo_screenwidth()
window_height = gui.winfo_screenheight()
canvas = Canvas(gui, width=window_width, height=window_height, background='light blue')
canvas.pack()
canvas.focus_set()

########################## YOUR CODE BELOW THIS LINE ##############################
#making land
canvas.create_rectangle([(0, window_height), (window_width, 500)], fill = 'light green')
    
#making sun
def make_sun(canvas, center:tuple, color='yellow', tag='sun'):
    utilities.make_circle(canvas, (center[0], center[1]), radius = 300, color = color, outline='orange')
make_sun(canvas, (0, 0))

#calling trees with random-colored leaves everytime you call the landscape (landscape object)
palette = ['royalblue', 'cornflowerblue', 'lightsteelblue', 'mistyrose', 'lightsalmon', 'tomato', 'green']
helpers.make_landscape_object(canvas, (800, 500), random.randint(75, 110), 'tree_1')
helpers.make_landscape_object(canvas, (600, 700), random.randint(75, 110), 'tree_2')
helpers.make_landscape_object(canvas, (300, 680), random.randint(75, 110), 'tree_3')
helpers.make_landscape_object(canvas, (500, 625), random.randint(75, 110), 'tree_4')
helpers.make_landscape_object(canvas, (200, 584), random.randint(75, 110), 'tree_5')
helpers.make_landscape_object(canvas, (1100, 700), random.randint(75, 110), 'tree_6')
helpers.make_landscape_object(canvas, (1250, 640), random.randint(75, 110), 'tree_7')

#calling snowmen (creatures)
helpers.make_creature(canvas, (1300, 650), tag='snowman_1')
helpers.make_creature(canvas, (500, 400), tag='snowman_2')
helpers.make_creature(canvas, (800, 225), tag='snowman_3')
helpers.make_creature(canvas, (1000, 680), tag='snowman_4')
helpers.make_creature(canvas, (100, 610), size=200, tag='snowman_5')

   
#right-click to delete snowmen 
RIGHT_CLICK = '<Button-2>'
def remove_snowman(event):
    tag = utilities.get_tag_from_x_y_coordinate(canvas, event.x, event.y)
    utilities.delete_by_tag(canvas, tag)
canvas.bind(RIGHT_CLICK, remove_snowman)

#move snowmen by clicking them and using arrow keys
MOUSE_CLICK = '<Button-1>'
KEY_PRESS='<Key>'
active_tag = None
def select_snowman(event):
    global active_tag
    tag = utilities.get_tag_from_x_y_coordinate(canvas, event.x, event.y)
    active_tag=tag
def move_snowman(event):
    distance = 10
    if event.keycode == 8124162:
        utilities.update_position_by_tag(canvas, active_tag, x=-distance, y=0)
    elif event.keycode == 8320768:
        utilities.update_position_by_tag(canvas, active_tag, x=0, y=-distance)
    elif event.keycode == 8189699:
        utilities.update_position_by_tag(canvas, active_tag, x=distance, y=0)
    elif event.keycode == 8255233:
        utilities.update_position_by_tag(canvas, active_tag, x=0, y=distance)
canvas.bind(MOUSE_CLICK, select_snowman)
canvas.bind(KEY_PRESS, move_snowman)

#create mini-snowmen that loop at continuously around upwards by dragging the mouse
MOUSE_DRAG = '<B1-Motion>'
snowman_info = []
def make_snowman(event):
    tag = 'mini_snowman' + str(len(snowman_info))
    helpers.make_creature(
        canvas,
        (event.x, event.y),
        25, 
        color=random.choice(palette),
        tag=tag
    )
    snowman_info.append({
        'tag': tag,
        'speed': random.uniform(1, 5)
    })
    
canvas.bind(MOUSE_DRAG, make_snowman)    

timer = 1
timer_2 = 1
while True:
    for snowman in snowman_info:
        tag = snowman['tag']
        speed = -1 * snowman['speed'] * math.cos(5*timer_2)*20
        if utilities.get_bottom(canvas, tag) == True:
            reset_snowman = window_height + utilities.get_width(canvas, tag)
            utilities.update_position_by_tag(canvas, tag=tag, y=reset_snowman)
        utilities.update_position_by_tag(canvas, tag=tag, x=0, y=speed)
    gui.update()
    time.sleep(1/30)
    timer_2 += 1
    if timer_2 % 10 == 0: 
        timer += 1
    if timer_2 % 30 == 0:
        #make a snowman army that you can move/delete all at once by periodically adding them to the landscape
        helpers.make_creature(canvas, (random.randint(150, (window_width-200)), random.randint(200, 600),'weird_snowman_' + str(timer_2)), color=random.choice(palette))
    #make big snowman continuously loop from right to left across screen while constantly accelerating
    utilities.update_position_by_tag(canvas, 'snowman_5', x = timer*3, y=0)
    gui.update()
    time.sleep(1/30)
    if utilities.get_left(canvas, 'snowman_5') > window_width:
        utilities.update_position_by_tag(canvas, 'snowman_5', x=-1700, y=0)
    #make sun periodically change color from red to yellow
    if timer_2 % 50 == 0:
        make_sun(canvas, (0,0), color='red')
    if timer_2 % 150 == 0:
        make_sun(canvas, (0,0), color='yellow')
    if timer_2 % 50 == 0 and timer_2 % 150 == 0:
        continue
    
   


########################## YOUR CODE ABOVE THIS LINE ############################## 

# makes sure the canvas keeps running:
canvas.mainloop()
