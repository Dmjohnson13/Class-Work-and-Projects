import utilities
import random

palette = ['royalblue', 'cornflowerblue', 'lightsteelblue', 'mistyrose', 'lightsalmon', 'tomato', 'green']

#function for making trees
def make_landscape_object(canvas, center:tuple, size=100, tag='landscape_object'):
    #making wood
    utilities.make_rectangle(canvas, (center[0] - size/1.5, center[1] - size/1.5), size/5, size*1.5, color = '#5C4033', tag=tag)
    #making leaves
    utilities.make_circle(canvas, (center[0] - size/1.2, center[1] - size/1.3), size*0.3, color=random.choice(palette), tag=tag)
    utilities.make_circle(canvas, (center[0] - size/1.7, center[1] - size/1.1), size*0.3, color=random.choice(palette), tag=tag)
    utilities.make_circle(canvas, (center[0] - size/2.7, center[1] - size/1.3), size*0.3, color=random.choice(palette), tag=tag)





#snowman function
def make_creature(canvas, center, size=100, tag='creature', color='white'):
    utilities.make_circle(canvas, (center[0], center[1] + size/2), size*0.4, color=color, outline='black', tag=tag)
    utilities.make_circle(canvas, (center[0], center[1]) , size*0.25, color=color, outline='black', tag=tag)
    utilities.make_circle(canvas, (center[0], center[1] - size/2.5), size*0.25, color=color, outline='black', tag=tag)
    utilities.make_oval(canvas, (center[0], center[1] - size/1.5), size*0.25, size*0.05, color='black', tag=tag)
    utilities.make_rectangle(canvas, (center[0]-size*0.1, center[1] - size/1.2), size*0.2, size*0.2, color='black', outline='black', tag=tag)
    utilities.make_circle(canvas, (center[0]-size*0.1, center[1] - size/2.5), size*0.03, color='black', tag=tag)
    utilities.make_circle(canvas, (center[0] + size*0.1, center[1] - size/2.5), size*0.03, color='black', tag=tag)
    utilities.make_line(canvas, [
        (center[0] + size*0.1, center[1] - size/3.1),
        (center[0], center[1] - size/3.8),
        (center[0] - size*0.1, center[1] - size/3.1)
        ], curvy=True, tag=tag)

  
                        

                                
                                
    
    
    

    

