from os import name
from apis import yelp
from apis import twilio

input_category_list = None
sort_by_selection = None
location_search = 'Evanston, IL'
search_term = None
price_filter = None
open_now_yes_no = False
open_now_display = "Not Filtering By Open Now"
hot_and_new = 'hot_and_new'
hot_and_new_display = "No"
selected_business = None

def print_menu():
    print('''
---------------------------------------------------------------------
Settings / Browse Options
---------------------------------------------------------------------
''')
    print("'B' - Browse matching restaurants")
    print('\n')
    print("1 - Update category filters | Currently: ", input_category_list)
    print("2 - Order by | Currently: ", sort_by_selection)
    print("3 - Update location. | Currently: ", location_search)
    print("4 - Enter, update, or clear a search term. | Currently: ", search_term)
    print("5 - Enter, update, or clear a price filter. | Currently: ", price_filter)
    print("6 - Filter list by open now? | Currently: ", open_now_display)
    print("7 - Filter by hot and new? | Currently: ", hot_and_new_display)
    
    print("8 - Quit")
    
    print('''
---------------------------------------------------------------------
    ''')

def handle_category_selection():
    
    # 1. Allow user to select one or more categories using the 
    #    yelp.get_genres_abridged() function
    # 2. Allow user to store / modify / retrieve categories
    #    in order to filter restaurants 

    print('''
        What would you like to do?

        1. [ ] Select categories
        2. [ ] clear categories

        ''')

    while True: 
        category_selection_options = input("Please enter a number: ")


        if category_selection_options == '1':

            print('Restaraunt categories')

            categories_list = yelp.get_categories()
            category_list_number = 1
            for category in categories_list:
                print(str(category_list_number) + ".", " [ ]", category)
                category_list_number +=1
            
            while True:
                try: 
                    # input category as a comma separated list
                    category_selection = [int(x) for x in input("Please enter a comma deliminated list: ").split(',')]

                    # list to put categories in
                    global input_category_list
                    input_category_list = []

                    # make indexable number from inputs, append actual list 
                    for num in category_selection:
                        indexable_num = num - 1
                        input_category_list.append(categories_list[indexable_num])

                    if len(input_category_list) != len(set(input_category_list)):
                        print("You entered two of the same categories, an invalid input.\nPlease try again.\n")
                        continue

                    
                    break

                except:
                    print("\nYou did not enter a comma deliminated list, or your number was out of range.\nPlease enter the numbers representing the categories.\n")
                    continue

        elif category_selection_options == '2':
            input_category_list = None
            print("Categories have been cleared.")

        else: 
            print("That wasn't an option. Please try again")
            continue
        
        break

        # except:
        #     print("That wasn't an option. Please try again")
        #     continue


    
def handle_ordering():
    print('\n')
    # Allow the user to determine how they want to sort the search results
    # Available options include: best_match, rating, review_count, distance.

    sort_by_options = ['best_match', 'rating', 'review_count', 'distance']

    sort_by_options_list_number = 1
    for sort_by_option in sort_by_options:
        print(str(sort_by_options_list_number) + ".", " [ ]", sort_by_option)
        sort_by_options_list_number +=1

    while True: 
        try: 
            sort_by_input = int(input('Please enter the number to sort by that choice: '))
            global sort_by_selection
            sort_by_selection = sort_by_options[sort_by_input - 1]
            print('\n')
            print("You are now sorting by", sort_by_selection)
            break
        except: 
            print("That wasn't an option. Please try again.\n")
            continue


def get_matching_restaurants():
    print('Retrieve matching restaurants...')
    # 1. Allow user to retrieve restaurant recommendations using the
    #    yelp.get_businesses() function
    # 2. List them below

    if input_category_list == None:
        global businesses
        businesses = yelp.get_businesses(
            #categories = ','.join(input_category_list), # if there's no categories, than don't get an error from this line
            sort_by = sort_by_selection,
            location = location_search,
            term = search_term,
            price = price_filter,
            open_now= open_now_yes_no,
            attributes = hot_and_new
            )

        display_text = yelp.get_formatted_business_list_table(businesses)
        print(display_text)

    else:
        businesses = yelp.get_businesses(
            categories = ','.join(input_category_list),
            sort_by = sort_by_selection,
            location = location_search,
            term = (search_term),
            open_now= open_now_yes_no,
            attributes = hot_and_new,
            price = price_filter
            )

        display_text = yelp.get_formatted_business_list_table(businesses)
        print(display_text)    

def handle_location():
    global location_search
    print('\n')
    location_search = input("Please enter the City and State or Zipcode you would like to search by: ")
    print("You are now searching in :", location_search)

def handle_search_term(): 

    print('''
    What would you like to do?

    1. [ ] Enter search term
    2. [ ] Clear search term

    ''')

    while True: 
        search_term_options_selection = input("Please enter a number: ")
    
    
        if search_term_options_selection == '1':
            global search_term
            print('\n')
            search_term = input('Please enter a search term: ')
            print('\nYou are now searching with the term ', search_term + '.')
            break
        elif search_term_options_selection == '2':
            #global search_term
            search_term = None
            print('\nThe search term has been cleared.')
            break
        else: 
            print("That was not one of the options. Please try again.\n")
            continue

def handle_price_filter(): 
    print('''
    What would you like to do?

    1. [ ] Enter price filter
    2. [ ] Clear price filter

    ''')

    while True: 
        price_filter_options_selection = (input("Please enter a number: "))

        if price_filter_options_selection == '1':
            global price_filter

            print('''
            Price filtering options: 

            1. [ ] $
            2. [ ] $$
            3. [ ] $$$
            4. [ ] $$$$
            ''')
            
            while True: 
                price_filter = input("Please enter a comma deliminated list for the number of dollar signs you'd like to search with: ")
                price_options = [1, 2, 3, 4]
                price_filter_clean = []
                price_filter_list = price_filter.split(',')
                errors = False
                try: 
                    for x in price_filter_list: 
                        x = int(x)
                        if x in price_options:
                            price_filter_clean.append(x)
                        else: 
                            print("Not a valid price filter. Try again. ")
                            errors = True
                            
                            break
                    if errors == True:
                        continue                             
                    
                    
                    price_filter = [str(element) for element in price_filter_clean]
                    price_filter = ",".join(price_filter)

                    break
                except:
                    print("Please try again, with only numbers separated by commas.")
                    continue

                

            


            print('\nYour price filter selection has been stored.')
            
            break
        
        elif price_filter_options_selection == '2':
            price_filter = None

            print('\nPrice filter has been cleared.')
            break

        else: 
                print("That was not one of the options. Please try again.\n")
                continue
        
def handle_hot_and_new():
    global hot_and_new
    global hot_and_new_display
    while True:
        hot_and_new_input = input("Filter by hot and new restaraunts (T/F)?: ")
        if hot_and_new_input.upper() == "T":
            hot_and_new = 'hot_and_new'
            hot_and_new_display = "Yes"
            print("\nFiltering by hot and new.\n")
            break
        elif hot_and_new_input.upper() == "F":
            hot_and_new = None
            hot_and_new_display = "No"
            print("\nWill not filter by hot and new.\n")
            break
        else: 
            print(hot_and_new_input, "wasn't a valid choice. Try again.\n")
            continue

def handle_open_now(): 
    global open_now_yes_no
    global open_now_display
    while True:
        open_now_input = input("Filter by restaraunts that are open now? (Y/N): ")
        open_now_input = open_now_input.upper()
        if open_now_input == "Y":
            open_now_yes_no = True
            open_now_display = "Only Restaraunts Open Now"
            print("\nOpen Now filtering preference saved.")
            break
        elif open_now_input == "N":
            open_now_yes_no = False
            open_now_display = "Not Filtering Restaraunts Only Open Now"
            print("\nNo filtering for only open now restaraunts.")
            break
        else: 
            print(open_now_input, "wasn't a valid choice. Try again.\n")
            continue




# Begin Main Program Loop:
while True:
    print_menu()
    choice = input('What would you like to do? ')
    if choice == '1':
        handle_category_selection()
    elif choice == '2':
        handle_ordering()
    elif choice.upper() == 'B':
        get_matching_restaurants()
        # In addition to showing the matching restaurants, allow the user to: 
        # (a) select an individual restaurant and view its ratings, and 
        # (b) email a restaurant to one or more of their friends using
        #     the sendgrid.send_mail() function.

        print('''
            ---------------------------------------------------------------------
            What would you like to do with these result?
            ---------------------------------------------------------------------
            1 - Get more info on an individual restaurant
            2 - Get reviews for an individual restaurant
            3 - Save this table as an HTML file
            4 - Go back to search preferences
            ---------------------------------------------------------------------
            ''')

        while True: 

            restarurant_result_choice = input('What would you like to do? ')

            if restarurant_result_choice == '1':
                while True:
                    selected_business = input("Please select a business by its number: ")
                    
                    try:
                        selected_business = int(selected_business)
                        if selected_business in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
                            selected_business = selected_business - 1 #need to account for ordering
                            print(yelp._get_business_display_text(businesses[selected_business]))
                            break
                        else:
                            print("You did not select a number in range. Try again.\n")
                            continue
                    except:
                        print('That was an invalid choice. Please try again.\n')
                        continue

                

                print('''
                ---------------------------------------------------------------------
                What would you like to do with this business table?
                ---------------------------------------------------------------------
                1 - Email this result
                2 - Get reviews for an individual restaurant
                ---------------------------------------------------------------------
                ''')

                while True:

                    single_result_choice = input('Please enter an option: ')

                    if single_result_choice == '1':

                        bus_name = businesses[selected_business].get('name')

                        from_email = input("Enter your email: ")

                        recipients = []
                        while True:
                            recipient = input("Who would you like to send the email to?\nPress enter if you're done. ")
                            if recipient == "":
                                break
                            recipients.append(recipient)
                            print("Sending email to:", recipients, "\n")

                        #to_email = input("Enter the email to send the message to: ")
                        subject = bus_name
                        html_content = yelp._get_business_display_html(businesses[selected_business])
                        email_return = twilio.send_mail(from_email, recipients, subject, html_content)

                        if email_return == True: 
                            None

                        if email_return == False:
                            print('Email failed. Sorry')
                        break

                    elif single_result_choice == '2':
                        bus_name = businesses[selected_business].get('name')
                        bus_id = businesses[selected_business].get('id')
                        reviews = yelp.get_reviews(bus_id)
                        #print(reviews)

                        print('---------------------------------------------------------------------')
                        print(bus_name)
                        print('---------------------------------------------------------------------')

                        print(yelp._get_reviews_display_text(reviews))
                        break

                    else:
                        print("That was not a valid option. Try again.\n")
                        continue

                    
                    
                break



                    
            elif restarurant_result_choice == '2':

                while True:
                    selected_business = input("Please select a business by its number: ")
                    if selected_business in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']:
                        selected_business = int(selected_business)
                        break
                    else: 
                        print("That was not a valid selection. Try again.\n")
                        continue

                selected_business = selected_business - 1 #need to account for ordering
                bus_id = businesses[selected_business].get('id')
                bus_name = businesses[selected_business].get('name')
                reviews = yelp.get_reviews(bus_id)
                #print(reviews)

        
                print('---------------------------------------------------------------------')
                print('Reviews for ', bus_name)
                print('---------------------------------------------------------------------')

                print(yelp._get_reviews_display_text(reviews))

                while True: 
                        reviews_back_input = input("Press enter to go back to the filtering menu. ")
                        if reviews_back_input == "":
                            break
                        else:
                            print("Not a valid input. Please try again.\n")
                            continue
                break                    

            elif restarurant_result_choice == '3':

                text_of_html_file = yelp._get_business_display_html_ourown(businesses) #modified our own function to make the chart in the yelp file. 

                file = open("businesslist.html", "w")
                file.write(text_of_html_file)
                file.close()
                print("File saved! Check the project 2 folder.\n")

                while True: 
                    reviews_back_input = input("Press enter to go back to the filtering menu. ")
                    if reviews_back_input == "":
                        break
                    else:
                        print("Not a valid input. Please try again.\n")
                        continue
                break       

            elif restarurant_result_choice == '4':
                break
            else: 
                print(restarurant_result_choice, 'is an invalid choice. Please try again.\n')
                continue

            
    elif choice == '3':
        handle_location()
    elif choice == '4':
        handle_search_term()
    elif choice == '5':
        handle_price_filter()
    elif choice == '6':
        handle_open_now()
    elif choice == '7':
        handle_hot_and_new()
    elif choice == '8':
        print('Quitting...')
        break
    else:
        print(choice, 'is an invalid choice. Please try again.')
    print()
    input('Press enter to continue...')

    # TO DO: 
        # Price filtering 

