from apis import yelp

businesses = yelp.get_businesses(
    location = 'Cherry Hill, NJ', 
    term="american", 
    price=2, 
    sort_by="review_count") 

template = '{name:<30.30}{rating:>10}{review_count:>20}'
print('-' * 60)
print(template.format(name='NAME', rating='RATING', review_count='REVIEW COUNT'))
print('-' * 60)
for business in businesses:
    print(template.format(
        name=business.get('name'), 
        rating=business.get('rating'), 
        review_count=business.get('review_count')))
print('-' * 60)

